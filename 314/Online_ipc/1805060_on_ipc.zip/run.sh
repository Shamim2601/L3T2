gcc -o test test-toggle.c zemaphore.c -lpthread 
./test